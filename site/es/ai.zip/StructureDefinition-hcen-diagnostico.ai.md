# HCEN Diagnóstico - Guía de Implementación FHIR de Uruguay v0.2.0

## Perfil de los recursos: HCEN Diagnóstico 

**Usos:**

* Referencia a este perfil: [HCEN Consulta No Urgente](StructureDefinition-uy-consulta-no-urgente.md)
* Ejemplos de este perfil: [Condition/hcen-diagnostico-desgarro-muscular](Condition-hcen-diagnostico-desgarro-muscular.md)

También se pueden consultar [los usos en FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.uy|current/StructureDefinition/hcen-diagnostico)

### Vistas formales del contenido del perfil

 [Descripción de perfiles, diferenciales, instantáneas y sus representaciones](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tabla de elementos clave](#tabs-key) 
*  [Tabla diferencial](#tabs-diff) 
*  [Tabla snapshot](#tabs-snap) 
*  [Estadísticas/Referencias](#tabs-summ) 
*  [Todos](#tabs-all) 

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [Condition](http://hl7.org/fhir/R4/condition.html) .

#### Bindings terminológicos (diferencial)

#### Restricciones

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [Condition](http://hl7.org/fhir/R4/condition.html) .

** Resumen **

Obligatorios: 5 elementos(3 elementosos obligatorios anidados)
 Must-Support: 1 elementos
 Fijos: 3 elementos
 Prohibidos: 12 elementos

**Estructuras**

Esta estructura referencia las siguientes estructuras:

* [Perfil Paciente para HCEN (http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient)](StructureDefinition-hcen-patient.md)

**Slices**

Esta estructura define los siguientes [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* El elemento 1 se divide en slices según el valor de Condition.code.coding
* El elemento 1 se divide en slices según el valor de Condition.onset[x]

 **Vista de elementos clave** 

#### Bindings terminológicos

#### Restricciones

 **Vista diferencial** 

Esta estructura se deriva de [Condition](http://hl7.org/fhir/R4/condition.html) .

#### Bindings terminológicos (diferencial)

#### Restricciones

 **Vista instantáneaView** 

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [Condition](http://hl7.org/fhir/R4/condition.html) .

** Resumen **

Obligatorios: 5 elementos(3 elementosos obligatorios anidados)
 Must-Support: 1 elementos
 Fijos: 3 elementos
 Prohibidos: 12 elementos

**Estructuras**

Esta estructura referencia las siguientes estructuras:

* [Perfil Paciente para HCEN (http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient)](StructureDefinition-hcen-patient.md)

**Slices**

Esta estructura define los siguientes [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* El elemento 1 se divide en slices según el valor de Condition.code.coding
* El elemento 1 se divide en slices según el valor de Condition.onset[x]

 

Otras representaciones de perfil: [CSV](../StructureDefinition-hcen-diagnostico.csv), [Excel](../StructureDefinition-hcen-diagnostico.xlsx), [Schematron](../StructureDefinition-hcen-diagnostico.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcen-diagnostico",
  "url" : "http://fhir.hcen.gub.uy/StructureDefinition/hcen-diagnostico",
  "version" : "0.2.0",
  "name" : "HCENDiagnostico",
  "title" : "HCEN Diagnóstico",
  "status" : "draft",
  "date" : "2026-10-28T18:02:56-03:00",
  "publisher" : "AGESIC",
  "contact" : [{
    "name" : "AGESIC",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gub.uy/agencia-gobierno-electronico-sociedad-informacion-conocimiento/salud-digital"
    }]
  }],
  "description" : "Diagnóstico registrado en la Hoja de Consulta No Urgente (CNU), modelado como Condition con category fija 'diagnostico'.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "HCENDiagnosticoToCDA",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)",
    "comment" : "Mapeo a HL7 CDA R2, según la columna \"Mapeo CDA\" de la hoja HCEN|UYDiagnostico."
  },
  {
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "sct-concept",
    "uri" : "http://snomed.info/conceptdomain",
    "name" : "SNOMED CT Concept Domain Binding"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "sct-attr",
    "uri" : "http://snomed.org/attributebinding",
    "name" : "SNOMED CT Attribute Binding"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Condition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Condition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Condition",
      "path" : "Condition",
      "short" : "Diagnóstico de una Consulta No Urgente",
      "definition" : "Condition que representa un diagnóstico registrado en una Hoja de Consulta No Urgente de HCEN."
    },
    {
      "id" : "Condition.implicitRules",
      "path" : "Condition.implicitRules",
      "max" : "0"
    },
    {
      "id" : "Condition.language",
      "path" : "Condition.language",
      "short" : "Idioma del recurso — fijo a es-UY",
      "definition" : "Idioma del recurso — fijo a es-UY",
      "min" : 1,
      "fixedCode" : "es-UY"
    },
    {
      "id" : "Condition.modifierExtension",
      "path" : "Condition.modifierExtension",
      "max" : "0"
    },
    {
      "id" : "Condition.identifier",
      "path" : "Condition.identifier",
      "max" : "0"
    },
    {
      "id" : "Condition.clinicalStatus",
      "path" : "Condition.clinicalStatus",
      "short" : "Estado del diagnóstico al cierre de la consulta. Mapeo CDA: problema resuelto → resolved; problema no resuelto → active (default)",
      "definition" : "Estado del diagnóstico al cierre de la consulta. Mapeo CDA: problema resuelto → resolved; problema no resuelto → active (default)",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/condition-clinical"
      }
    },
    {
      "id" : "Condition.verificationStatus",
      "path" : "Condition.verificationStatus",
      "short" : "Grado de certeza del diagnóstico (p.ej. provisional, confirmed)",
      "definition" : "Grado de certeza del diagnóstico (p.ej. provisional, confirmed)",
      "min" : 1,
      "binding" : {
        "strength" : "required",
        "valueSet" : "http://hl7.org/fhir/ValueSet/condition-ver-status"
      }
    },
    {
      "id" : "Condition.category",
      "path" : "Condition.category",
      "short" : "Identifica este Condition como un diagnóstico",
      "definition" : "Identifica este Condition como un diagnóstico",
      "min" : 1,
      "max" : "1",
      "fixedCodeableConcept" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "439401001",
          "display" : "Diagnostico"
        }]
      },
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.hcen.gub.uy/ValueSet/vs-condition-category-cnu"
      },
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/code"
      }]
    },
    {
      "id" : "Condition.category.coding.system",
      "path" : "Condition.category.coding.system",
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/code/@codeSystem"
      }]
    },
    {
      "id" : "Condition.category.coding.code",
      "path" : "Condition.category.coding.code",
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/code/@code"
      }]
    },
    {
      "id" : "Condition.severity",
      "path" : "Condition.severity",
      "max" : "0"
    },
    {
      "id" : "Condition.code",
      "path" : "Condition.code",
      "short" : "Código que identifica el diagnóstico (SNOMED CT u otra terminología, p.ej. un tesauro clínico institucional)",
      "definition" : "Código que identifica el diagnóstico (SNOMED CT u otra terminología, p.ej. un tesauro clínico institucional)",
      "min" : 1,
      "constraint" : [{
        "key" : "hcen-coding-required-1",
        "severity" : "error",
        "human" : "code.coding debe tener al menos una entrada (al menos una codificación).",
        "expression" : "coding.exists()",
        "source" : "http://fhir.hcen.gub.uy/StructureDefinition/hcen-diagnostico"
      }]
    },
    {
      "id" : "Condition.code.coding",
      "path" : "Condition.code.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "system"
        }],
        "rules" : "open"
      },
      "short" : "Slicing abierto por system: además del slice snomed, admite otra codificación con su propio system — p.ej. un código de un tesauro clínico (ver sección 4.7.4 Tesauro clínico)",
      "definition" : "El slicing es abierto por system. Además del slice snomed, se puede incluir una codificación adicional de otro vocabulario — p.ej. un código de un tesauro clínico (ver [Tesauro clínico](hcen-terminologia.html#tesauro-clínico), sección 4.7.4). La URI de ese system depende de la institución de origen y su confirmación es externa a esta guía; no se fija ni se valida en este perfil."
    },
    {
      "id" : "Condition.code.coding:snomed",
      "path" : "Condition.code.coding",
      "sliceName" : "snomed",
      "short" : "Código SNOMED CT del diagnóstico",
      "definition" : "Código SNOMED CT del diagnóstico",
      "min" : 0,
      "max" : "1",
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation[code/@code='439401001']/value"
      }]
    },
    {
      "id" : "Condition.code.coding:snomed.system",
      "path" : "Condition.code.coding.system",
      "min" : 1,
      "fixedUri" : "http://snomed.info/sct",
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/value/@codeSystem"
      }]
    },
    {
      "id" : "Condition.code.coding:snomed.code",
      "path" : "Condition.code.coding.code",
      "min" : 1,
      "binding" : {
        "strength" : "extensible",
        "valueSet" : "http://fhir.hcen.gub.uy/ValueSet/vs-diagnostico-consulta"
      },
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/value/@code"
      }]
    },
    {
      "id" : "Condition.code.coding:snomed.display",
      "path" : "Condition.code.coding.display",
      "short" : "Texto descriptivo del código SNOMED CT del diagnóstico",
      "definition" : "Texto descriptivo del código SNOMED CT del diagnóstico",
      "min" : 1,
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/value/@displayName"
      }]
    },
    {
      "id" : "Condition.bodySite",
      "path" : "Condition.bodySite",
      "max" : "0"
    },
    {
      "id" : "Condition.subject",
      "path" : "Condition.subject",
      "short" : "Paciente al que se le asocia el diagnóstico",
      "definition" : "Paciente al que se le asocia el diagnóstico",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient"]
      }],
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "ClinicalDocument/recordTarget/patientRole/id"
      }]
    },
    {
      "id" : "Condition.onset[x]",
      "path" : "Condition.onset[x]",
      "slicing" : {
        "discriminator" : [{
          "type" : "type",
          "path" : "$this"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "short" : "Inicio del problema de salud (fecha exacta, edad aproximada, período o rango)",
      "definition" : "Inicio del problema de salud (fecha exacta, edad aproximada, período o rango)",
      "mustSupport" : true,
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/effectiveTime"
      }]
    },
    {
      "id" : "Condition.onset[x]:onsetAge",
      "path" : "Condition.onset[x]",
      "sliceName" : "onsetAge",
      "short" : "Edad aproximada del paciente cuando comenzó con el problema de salud",
      "definition" : "Edad aproximada del paciente cuando comenzó con el problema de salud.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Age"
      }]
    },
    {
      "id" : "Condition.onset[x]:onsetPeriod",
      "path" : "Condition.onset[x]",
      "sliceName" : "onsetPeriod",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Period"
      }]
    },
    {
      "id" : "Condition.onset[x]:onsetPeriod.start",
      "path" : "Condition.onset[x].start",
      "short" : "Fecha de inicio del problema de salud",
      "definition" : "Indica la fecha de inicio del problema de salud.",
      "mapping" : [{
        "identity" : "HCENDiagnosticoToCDA",
        "map" : "section/entry/observation/effectiveTime/low/@value"
      }]
    },
    {
      "id" : "Condition.abatement[x]",
      "path" : "Condition.abatement[x]",
      "max" : "0"
    },
    {
      "id" : "Condition.recordedDate",
      "path" : "Condition.recordedDate",
      "max" : "0"
    },
    {
      "id" : "Condition.recorder",
      "path" : "Condition.recorder",
      "max" : "0"
    },
    {
      "id" : "Condition.asserter",
      "path" : "Condition.asserter",
      "max" : "0"
    },
    {
      "id" : "Condition.stage",
      "path" : "Condition.stage",
      "max" : "0"
    },
    {
      "id" : "Condition.evidence",
      "path" : "Condition.evidence",
      "max" : "0"
    },
    {
      "id" : "Condition.note",
      "path" : "Condition.note",
      "max" : "0"
    }]
  }
}

```
