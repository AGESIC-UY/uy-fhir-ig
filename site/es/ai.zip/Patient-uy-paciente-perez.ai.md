# example-uy-paciente-perez - Guía de Implementación FHIR de Uruguay v0.2.0

## Ejemplo Patient: example-uy-paciente-perez



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "uy-paciente-perez",
  "meta" : {
    "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/uy-patient"]
  },
  "language" : "es-UY",
  "extension" : [{
    "extension" : [{
      "url" : "value",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/administrative-gender",
          "code" : "male",
          "display" : "Male"
        }]
      }
    },
    {
      "url" : "type",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "76689-9",
          "display" : "Sex assigned at birth"
        }]
      }
    }],
    "url" : "http://hl7.org/fhir/StructureDefinition/individual-recordedSexOrGender"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "MR",
        "display" : "Medical record number"
      }]
    },
    "system" : "https://example.org/institucion/identificadores/pacientes",
    "value" : "MRN1234"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "NI",
        "display" : "National unique individual identifier"
      }]
    },
    "system" : "urn:oid:2.16.858.1.858.68909",
    "value" : "12345678"
  }],
  "active" : true,
  "name" : [{
    "text" : "Juan Carlos Pérez Rodríguez",
    "family" : "Pérez Rodríguez",
    "_family" : {
      "extension" : [{
        "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-primer-apellido",
        "valueString" : "Pérez"
      },
      {
        "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-segundo-apellido",
        "valueString" : "Rodríguez"
      }]
    },
    "given" : ["Juan", "Carlos"]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "+598 99 123 456",
    "use" : "mobile",
    "period" : {
      "start" : "2018"
    }
  },
  {
    "system" : "email",
    "value" : "juan.perez@example.com",
    "use" : "home"
  }],
  "gender" : "male",
  "birthDate" : "1980-01-01",
  "address" : [{
    "text" : "Calle Falsa 1234, CIUDAD VIEJA, MONTEVIDEO, Montevideo, URY",
    "line" : ["Calle Falsa 1234"],
    "city" : "MONTEVIDEO",
    "district" : "CIUDAD VIEJA",
    "state" : "Montevideo",
    "country" : "URY"
  }]
}

```
