# example-uy-organizacion-abc - Guía de Implementación FHIR de Uruguay v0.2.0

## Ejemplo Organization: example-uy-organizacion-abc



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "uy-organizacion-abc",
  "meta" : {
    "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/uy-organization"]
  },
  "language" : "es-UY",
  "identifier" : [{
    "use" : "official",
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX",
        "display" : "Organization identifier"
      }]
    },
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.16.858.0.0.2.1234"
  }],
  "active" : true,
  "name" : "Organización ABC",
  "telecom" : [{
    "system" : "phone",
    "value" : "+598 2486 5008",
    "use" : "work"
  }],
  "address" : [{
    "use" : "work",
    "type" : "both",
    "line" : ["Av. Luis Alberto de Herrera 1234"],
    "city" : "MONTEVIDEO",
    "state" : "Montevideo",
    "country" : "URY"
  }]
}

```
