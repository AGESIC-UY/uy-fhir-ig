# Sobre de publicación documental HCEN - Guía de Implementación FHIR de Uruguay v0.1.0

## Ejemplo Bundle: Sobre de publicación documental HCEN



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "hcen-publicacion-ejemplo",
  "meta" : {
    "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-provide-document-bundle"]
  },
  "type" : "transaction",
  "entry" : [{
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000009",
    "resource" : {
      "resourceType" : "List",
      "id" : "hcen-conjunto-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-submission-set"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"List_hcen-conjunto-ejemplo\"> </a><p>Conjunto de un documento ficticio de Ana Pérez Gómez, enviado por ANDA a efectos del ejemplo técnico el 17/09/2026.</p></div>"
      },
      "extension" : [{
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-designationType",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://loinc.org",
            "code" : "34108-1"
          }]
        }
      },
      {
        "url" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/ihe-sourceId",
        "valueIdentifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:oid:2.16.858.2.99999999"
        }
      }],
      "identifier" : [{
        "use" : "official",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:2.2.16.858.2.99999999.67430.20260917100000.1"
      },
      {
        "use" : "usual",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.858.2.99999999.67430.20260917100000.1"
      }],
      "status" : "current",
      "mode" : "working",
      "code" : {
        "coding" : [{
          "system" : "https://profiles.ihe.net/ITI/MHD/CodeSystem/MHDlistTypes",
          "code" : "submissionset"
        }]
      },
      "subject" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000001"
      },
      "date" : "2026-09-17T10:00:00-03:00",
      "source" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000004"
      },
      "entry" : [{
        "item" : {
          "reference" : "urn:uuid:00000000-0000-4000-8000-000000000008"
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "List"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000008",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "hcen-referencia-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-document-reference"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"DocumentReference_hcen-referencia-ejemplo\"> </a><p>Metadatos de un documento ficticio de Ana Pérez Gómez. Incluye referencias a FHIR y CDA, autoría de Lucía Silva y custodia de ANDA a efectos del ejemplo técnico.</p></div>"
      },
      "extension" : [{
        "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-repository-id",
        "valueIdentifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:oid:2.16.858.2.99999999.1"
        }
      }],
      "masterIdentifier" : {
        "use" : "usual",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.858.2.99999999.67430.20260917100000.1"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:1.2.16.858.2.99999999.67430.20260917100000.1"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6821000179104"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "34108-1"
        }]
      }],
      "subject" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000001"
      },
      "date" : "2026-09-17T10:00:00-03:00",
      "author" : [{
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000004"
      }],
      "custodian" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000003"
      },
      "securityLabel" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
          "code" : "N"
        }]
      }],
      "content" : [{
        "attachment" : {
          "extension" : [{
            "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-binary-resource-id",
            "valueReference" : {
              "reference" : "urn:uuid:00000000-0000-4000-8000-000000000007"
            }
          }],
          "contentType" : "application/fhir+json",
          "language" : "es-UY",
          "url" : "urn:uuid:00000000-0000-4000-8000-000000000006",
          "title" : "Documento de prueba de interoperabilidad",
          "creation" : "2026-09-17T10:00:00-03:00"
        },
        "format" : {
          "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
          "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient"
        }
      }],
      "context" : {
        "facilityType" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "22232009"
          }]
        },
        "practiceSetting" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "700232004"
          }]
        },
        "sourcePatientInfo" : {
          "reference" : "urn:uuid:00000000-0000-4000-8000-000000000001"
        }
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "DocumentReference"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000006",
    "resource" : {
      "resourceType" : "Bundle",
      "id" : "hcen-documento-ejemplo",
      "language" : "es",
      "identifier" : {
        "use" : "usual",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.858.2.99999999.67430.20260917100000.1"
      },
      "type" : "document",
      "timestamp" : "2026-09-17T10:00:00-03:00",
      "entry" : [{
        "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000005",
        "resource" : {
          "resourceType" : "Composition",
          "id" : "hcen-composicion-ejemplo",
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Documento de prueba de interoperabilidad de Ana Pérez Gómez, emitido por Lucía Silva en ANDA a efectos del ejemplo técnico el 17/09/2026. No contiene observaciones clínicas.</p></div>"
          },
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:2.16.858.2.99999999.67430.20260917100000.1"
          },
          "status" : "final",
          "type" : {
            "coding" : [{
              "system" : "http://loinc.org",
              "code" : "34108-1"
            }]
          },
          "subject" : {
            "reference" : "urn:uuid:00000000-0000-4000-8000-000000000001"
          },
          "date" : "2026-09-17T10:00:00-03:00",
          "author" : [{
            "reference" : "urn:uuid:00000000-0000-4000-8000-000000000004"
          }],
          "title" : "Documento de prueba de interoperabilidad",
          "confidentiality" : "N",
          "custodian" : {
            "reference" : "urn:uuid:00000000-0000-4000-8000-000000000003"
          },
          "section" : [{
            "title" : "Contenido de prueba",
            "text" : {
              "status" : "generated",
              "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Documento ficticio para pruebas de interoperabilidad. No contiene observaciones clínicas.</p></div>"
            }
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000001",
        "resource" : {
          "resourceType" : "Patient",
          "id" : "hcen-paciente-ejemplo",
          "meta" : {
            "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient"]
          },
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Ana Pérez Gómez. MRN-EJEMPLO-001. Registro activo; sexo administrativo femenino; nacimiento 20/05/1985.</p></div>"
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "MR",
                "display" : "Medical record number"
              }]
            },
            "system" : "urn:oid:2.16.858.2.99999999.72768.1",
            "value" : "MRN-EJEMPLO-001"
          }],
          "active" : true,
          "name" : [{
            "family" : "Pérez Gómez",
            "_family" : {
              "extension" : [{
                "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-primer-apellido",
                "valueString" : "Pérez"
              },
              {
                "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-segundo-apellido",
                "valueString" : "Gómez"
              }]
            },
            "given" : ["Ana"]
          }],
          "gender" : "female",
          "birthDate" : "1985-05-20"
        }
      },
      {
        "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000002",
        "resource" : {
          "resourceType" : "Practitioner",
          "id" : "hcen-profesional-ejemplo",
          "meta" : {
            "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner"]
          },
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Lucía Silva. Cédula de ejemplo 12345672.</p></div>"
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "NI",
                "display" : "National unique individual identifier"
              }]
            },
            "system" : "urn:oid:2.16.858.2.10000675.68909",
            "value" : "12345672"
          }],
          "name" : [{
            "family" : "Silva",
            "given" : ["Lucía"]
          }]
        }
      },
      {
        "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000003",
        "resource" : {
          "resourceType" : "Organization",
          "id" : "hcen-organizacion-ejemplo",
          "meta" : {
            "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-organization"]
          },
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>ANDA. OID institucional utilizado para validar el ejemplo: urn:oid:2.16.858.2.10014456.72768.1.</p></div>"
          },
          "identifier" : [{
            "type" : {
              "coding" : [{
                "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
                "code" : "XX",
                "display" : "Organization identifier"
              }]
            },
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:2.16.858.2.10014456.72768.1"
          }],
          "name" : "ANDA"
        }
      },
      {
        "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000004",
        "resource" : {
          "resourceType" : "PractitionerRole",
          "id" : "hcen-rol-ejemplo",
          "meta" : {
            "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner-role"]
          },
          "language" : "es",
          "text" : {
            "status" : "generated",
            "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Lucía Silva ejerce en ANDA a efectos del ejemplo técnico.</p></div>"
          },
          "practitioner" : {
            "reference" : "urn:uuid:00000000-0000-4000-8000-000000000002"
          },
          "organization" : {
            "reference" : "urn:uuid:00000000-0000-4000-8000-000000000003"
          }
        }
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Bundle"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000007",
    "resource" : {
      "resourceType" : "Binary",
      "id" : "hcen-cda-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-cda-binary"]
      },
      "language" : "es",
      "contentType" : "text/xml",
      "data" : "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPENsaW5pY2FsRG9jdW1lbnQgeG1sbnM9InVybjpobDctb3JnOnYzIiB4bWxuczp4c2k9Imh0dHA6Ly93d3cudzMub3JnLzIwMDEvWE1MU2NoZW1hLWluc3RhbmNlIj4KPHJlYWxtQ29kZSBjb2RlPSJVWSIvPjx0eXBlSWQgcm9vdD0iMi4xNi44NDAuMS4xMTM4ODMuMS4zIiBleHRlbnNpb249IlBPQ0RfSEQwMDAwNDAiLz4KPGlkIHJvb3Q9IjIuMTYuODU4LjIuOTk5OTk5OTkuNjc0MzAuMjAyNjA5MTcxMDAwMDAuMSIvPjxjb2RlIGNvZGU9IjM0MTA4LTEiIGNvZGVTeXN0ZW09IjIuMTYuODQwLjEuMTEzODgzLjYuMSIvPgo8dGl0bGU+RG9jdW1lbnRvIGRlIHBydWViYSBkZSBpbnRlcm9wZXJhYmlsaWRhZDwvdGl0bGU+PGVmZmVjdGl2ZVRpbWUgdmFsdWU9IjIwMjYwOTE3MTAwMDAwLTAzMDAiLz4KPGNvbmZpZGVudGlhbGl0eUNvZGUgY29kZT0iTiIgY29kZVN5c3RlbT0iMi4xNi44NDAuMS4xMTM4ODMuNS4yNSIvPjxsYW5ndWFnZUNvZGUgY29kZT0iZXMtVVkiLz4KPHNldElkIHJvb3Q9IjIuMTYuODU4LjIuOTk5OTk5OTkuNjc0MzAuMjAyNjA5MTcxMDAwMDAuMSIvPjx2ZXJzaW9uTnVtYmVyIHZhbHVlPSIxIi8+CjxyZWNvcmRUYXJnZXQ+PHBhdGllbnRSb2xlPjxpZCByb290PSIyLjE2Ljg1OC4yLjk5OTk5OTk5LjcyNzY4LjEiIGV4dGVuc2lvbj0iTVJOLUVKRU1QTE8tMDAxIi8+CjxwYXRpZW50PjxuYW1lPjxnaXZlbj5BbmE8L2dpdmVuPjxmYW1pbHk+UMOpcmV6IEfDs21lejwvZmFtaWx5PjwvbmFtZT48YWRtaW5pc3RyYXRpdmVHZW5kZXJDb2RlIGNvZGU9IkYiIGNvZGVTeXN0ZW09IjIuMTYuODQwLjEuMTEzODgzLjUuMSIvPjxiaXJ0aFRpbWUgdmFsdWU9IjE5ODUwNTIwIi8+PC9wYXRpZW50PjwvcGF0aWVudFJvbGU+PC9yZWNvcmRUYXJnZXQ+CjxhdXRob3I+PHRpbWUgdmFsdWU9IjIwMjYwOTE3MTAwMDAwLTAzMDAiLz48YXNzaWduZWRBdXRob3I+PGlkIHJvb3Q9IjIuMTYuODU4LjIuMTAwMDA2NzUuNjg5MDkiIGV4dGVuc2lvbj0iMTIzNDU2NzIiLz48YXNzaWduZWRQZXJzb24+PG5hbWU+PGdpdmVuPkx1Y8OtYTwvZ2l2ZW4+PGZhbWlseT5TaWx2YTwvZmFtaWx5PjwvbmFtZT48L2Fzc2lnbmVkUGVyc29uPjxyZXByZXNlbnRlZE9yZ2FuaXphdGlvbj48aWQgcm9vdD0iMi4xNi44NTguMi45OTk5OTk5OSIvPjxuYW1lPlByZXN0YWRvciBkZSBlamVtcGxvPC9uYW1lPjwvcmVwcmVzZW50ZWRPcmdhbml6YXRpb24+PC9hc3NpZ25lZEF1dGhvcj48L2F1dGhvcj4KPGN1c3RvZGlhbj48YXNzaWduZWRDdXN0b2RpYW4+PHJlcHJlc2VudGVkQ3VzdG9kaWFuT3JnYW5pemF0aW9uPjxpZCByb290PSIyLjE2Ljg1OC4yLjk5OTk5OTk5Ii8+PG5hbWU+UHJlc3RhZG9yIGRlIGVqZW1wbG88L25hbWU+PC9yZXByZXNlbnRlZEN1c3RvZGlhbk9yZ2FuaXphdGlvbj48L2Fzc2lnbmVkQ3VzdG9kaWFuPjwvY3VzdG9kaWFuPgo8Y29tcG9uZW50Pjxub25YTUxCb2R5Pjx0ZXh0IG1lZGlhVHlwZT0idGV4dC9wbGFpbiIgcmVwcmVzZW50YXRpb249IlRYVCI+RG9jdW1lbnRvIGZpY3RpY2lvIHBhcmEgcHJ1ZWJhcyBkZSBpbnRlcm9wZXJhYmlsaWRhZC4gTm8gY29udGllbmUgb2JzZXJ2YWNpb25lcyBjbMOtbmljYXMuPC90ZXh0Pjwvbm9uWE1MQm9keT48L2NvbXBvbmVudD4KPC9DbGluaWNhbERvY3VtZW50Pg=="
    },
    "request" : {
      "method" : "POST",
      "url" : "Binary"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000001",
    "resource" : {
      "resourceType" : "Patient",
      "id" : "hcen-paciente-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"Patient_hcen-paciente-ejemplo\"> </a><p>Ana Pérez Gómez. MRN-EJEMPLO-001. Registro activo; sexo administrativo femenino; nacimiento 20/05/1985.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "MR",
            "display" : "Medical record number"
          }]
        },
        "system" : "urn:oid:2.16.858.2.99999999.72768.1",
        "value" : "MRN-EJEMPLO-001"
      }],
      "active" : true,
      "name" : [{
        "family" : "Pérez Gómez",
        "_family" : {
          "extension" : [{
            "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-primer-apellido",
            "valueString" : "Pérez"
          },
          {
            "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-segundo-apellido",
            "valueString" : "Gómez"
          }]
        },
        "given" : ["Ana"]
      }],
      "gender" : "female",
      "birthDate" : "1985-05-20"
    },
    "request" : {
      "method" : "POST",
      "url" : "Patient"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000002",
    "resource" : {
      "resourceType" : "Practitioner",
      "id" : "hcen-profesional-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"Practitioner_hcen-profesional-ejemplo\"> </a><p>Lucía Silva. Cédula de ejemplo 12345672.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "NI",
            "display" : "National unique individual identifier"
          }]
        },
        "system" : "urn:oid:2.16.858.2.10000675.68909",
        "value" : "12345672"
      }],
      "name" : [{
        "family" : "Silva",
        "given" : ["Lucía"]
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "Practitioner"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000004",
    "resource" : {
      "resourceType" : "PractitionerRole",
      "id" : "hcen-rol-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner-role"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"PractitionerRole_hcen-rol-ejemplo\"> </a><p>Lucía Silva ejerce en ANDA a efectos del ejemplo técnico.</p></div>"
      },
      "practitioner" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000002"
      },
      "organization" : {
        "reference" : "urn:uuid:00000000-0000-4000-8000-000000000003"
      }
    },
    "request" : {
      "method" : "POST",
      "url" : "PractitionerRole"
    }
  },
  {
    "fullUrl" : "urn:uuid:00000000-0000-4000-8000-000000000003",
    "resource" : {
      "resourceType" : "Organization",
      "id" : "hcen-organizacion-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-organization"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"Organization_hcen-organizacion-ejemplo\"> </a><p>ANDA. OID institucional utilizado para validar el ejemplo: urn:oid:2.16.858.2.10014456.72768.1.</p></div>"
      },
      "identifier" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "XX",
            "display" : "Organization identifier"
          }]
        },
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.858.2.10014456.72768.1"
      }],
      "name" : "ANDA"
    },
    "request" : {
      "method" : "POST",
      "url" : "Organization"
    }
  }]
}

```
