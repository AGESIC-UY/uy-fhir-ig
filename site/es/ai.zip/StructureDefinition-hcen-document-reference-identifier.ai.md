# EntryUUID de DocumentReference HCEN - Guía de Implementación FHIR de Uruguay v0.2.0

## Perfil del tipo de datos: EntryUUID de DocumentReference HCEN 

**Usos:**

* Utilizar este perfil de tipo de datos: [Perfil Document Reference HCEN](StructureDefinition-hcen-document-reference.md)

También se pueden consultar [los usos en FHIR IG Statistics](https://packages2.fhir.org/xig/fhir.uy|current/StructureDefinition/hcen-document-reference-identifier)

### Vistas formales del contenido del perfil

 [Descripción de perfiles, diferenciales, instantáneas y sus representaciones](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tabla de elementos clave](#tabs-key) 
*  [Tabla diferencial](#tabs-diff) 
*  [Tabla snapshot](#tabs-snap) 
*  [Estadísticas/Referencias](#tabs-summ) 
*  [Todos](#tabs-all) 

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [EntryUUIDIdentifier](https://profiles.ihe.net/ITI/MHD/4.2.3/StructureDefinition-IHE.MHD.EntryUUID.Identifier.html) .

#### Restricciones

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [EntryUUIDIdentifier](https://profiles.ihe.net/ITI/MHD/4.2.3/StructureDefinition-IHE.MHD.EntryUUID.Identifier.html) .

** Resumen **

 **Vista de elementos clave** 

#### Bindings terminológicos

#### Restricciones

 **Vista diferencial** 

Esta estructura se deriva de [EntryUUIDIdentifier](https://profiles.ihe.net/ITI/MHD/4.2.3/StructureDefinition-IHE.MHD.EntryUUID.Identifier.html) .

#### Restricciones

 **Vista instantáneaView** 

#### Bindings terminológicos

#### Restricciones

Esta estructura se deriva de [EntryUUIDIdentifier](https://profiles.ihe.net/ITI/MHD/4.2.3/StructureDefinition-IHE.MHD.EntryUUID.Identifier.html) .

** Resumen **

 

Otras representaciones de perfil: [CSV](../StructureDefinition-hcen-document-reference-identifier.csv), [Excel](../StructureDefinition-hcen-document-reference-identifier.xlsx), [Schematron](../StructureDefinition-hcen-document-reference-identifier.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "hcen-document-reference-identifier",
  "url" : "http://fhir.hcen.gub.uy/StructureDefinition/hcen-document-reference-identifier",
  "version" : "0.2.0",
  "name" : "HCENDocumentReferenceIdentifier",
  "title" : "EntryUUID de DocumentReference HCEN",
  "status" : "draft",
  "date" : "2026-10-28T18:02:56-03:00",
  "publisher" : "AGESIC",
  "contact" : [{
    "name" : "AGESIC",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gub.uy/agencia-gobierno-electronico-sociedad-informacion-conocimiento/salud-digital"
    }]
  }],
  "description" : "Identificador técnico entryUUID de un DocumentReference HCEN, basado en el perfil IHE MHD EntryUUID Identifier.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "servd",
    "uri" : "http://www.omg.org/spec/ServD/1.0/",
    "name" : "ServD"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "type" : "Identifier",
  "baseDefinition" : "https://profiles.ihe.net/ITI/MHD/StructureDefinition/IHE.MHD.EntryUUID.Identifier",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Identifier",
      "path" : "Identifier",
      "short" : "EntryUUID de la referencia documental HCEN",
      "definition" : "Identificador técnico de la referencia documental, derivado del OID del documento con el formato urn:uuid:1.[oid_documento_clinico]."
    },
    {
      "id" : "Identifier.use",
      "path" : "Identifier.use",
      "short" : "Propósito del identificador: official.",
      "definition" : "IHE MHD EntryUUID Identifier requiere que use esté presente con el valor official."
    },
    {
      "id" : "Identifier.system",
      "path" : "Identifier.system",
      "short" : "Sistema URI de identificación: urn:ietf:rfc:3986.",
      "definition" : "Sistema URI de identificación: urn:ietf:rfc:3986."
    },
    {
      "id" : "Identifier.value",
      "path" : "Identifier.value",
      "short" : "URI urn:uuid:1.[oid_documento_clinico]",
      "definition" : "EntryUUID del DocumentReference formado anteponiendo urn:uuid:1. al OID del documento clínico.",
      "constraint" : [{
        "key" : "hcen-document-reference-entryuuid",
        "severity" : "error",
        "human" : "El entryUUID del DocumentReference se deriva del OID documental con el formato urn:uuid:1.[oid_documento_clinico].",
        "expression" : "matches('^urn:uuid:1[.]2[.]16[.]858[.]2[.](0|[1-9][0-9]*)[.]67430[.][1-9][0-9]{13}([.](0|[1-9][0-9]*))+$')",
        "source" : "http://fhir.hcen.gub.uy/StructureDefinition/hcen-document-reference-identifier"
      }]
    }]
  }
}

```
