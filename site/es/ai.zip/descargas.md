# Descargas - Guía de Implementación FHIR de Uruguay v0.2.0

## Descargas

El [paquete FHIR de esta compilación](../package.tgz) contiene los recursos de la guía y se genera con IG Publisher.

| | |
| :--- | :--- |
| Guía | Guía de Implementación FHIR de Uruguay |
| Identificador | `uy-fhir-ig` |
| Paquete | `fhir.uy`(identificador de trabajo pendiente de confirmación institucional) |
| URL canónica base | `http://fhir.hcen.gub.uy` |
| Versión | `0.2.0` |
| FHIR | R4 (`4.0.1`) |
| Estado | Borrador en desarrollo |

La URL canónica identifica de forma estable los artefactos y se conserva aunque cambie el lugar de publicación. Mientras se habilita el dominio `fhir.hcen.gub.uy`, la guía se publica en [GitHub Pages](https://agesic-uy.github.io/uy-fhir-ig/site/es/index.html). Para validar, se debe cargar el paquete de esta compilación junto con sus dependencias: las herramientas pueden resolver las canónicas desde el paquete sin descargar recursos de ese dominio.

El paquete incluye las definiciones del Core y de HCEN, junto con sus ejemplos. Los cambios respecto de versiones anteriores se describen en el [historial](cambios.md). Los catálogos de [perfiles HCEN](hcen-perfiles.md), [extensiones](hcen-extensiones.md), [terminología](hcen-terminologia.md) y [ejemplos](hcen-ejemplos.md) permiten localizar cada recurso. El alcance de la validación se explica en [Conformidad](conformidad.md).

Consultar el [historial de cambios](cambios.md).

