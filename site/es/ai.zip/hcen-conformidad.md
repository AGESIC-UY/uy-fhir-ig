# Conformidad y capacidades HCEN - Guía de Implementación FHIR de Uruguay v0.2.0

## Conformidad y capacidades HCEN

Esta sección define qué significa cumplir el contrato HCEN y cómo organizar la evidencia de una implementación. Se aplica a los [actores](hcen-actores.md) y utiliza el lenguaje de las [convenciones comunes](conformidad.md).

### Unidad de conformidad

El despliegue de un prestador debe (SHALL) cubrir íntegramente las cuatro transacciones del alcance.

La conformidad HCEN es local: no equivale a declarar conformidad IHE MHD o PIXm. Los perfiles clínicos incorporados se describen en [Documentos clínicos HCEN](hcen-documentos-clinicos.md).

### Must Support y ausencia de datos

El emisor debe (SHALL) enviar siempre un dato MS cuando lo conoce. Solo puede faltar si es desconocido y las cardinalidades y demás restricciones permiten su ausencia. Esta obligación se aplica al prestador cuando registra pacientes o publica metadatos y a Plataforma cuando emite recursos perfilados, por ejemplo en una consulta.

MS no autoriza elementos vacíos ni cambia su cardinalidad. Si falta un elemento obligatorio del recurso de intercambio, Plataforma debe (SHALL) rechazarlo. La cardinalidad de un elemento anidado se evalúa cuando existe su contenedor. El alcance de la validación del envío se detalla en [HCEN ITI-65](hcen-iti-65.md).

| | |
| :--- | :--- |
| Prestador como emisor de Patient o metadatos | Enviar todos los datos MS conocidos. |
| Plataforma como emisora de metadatos | Conservar en la respuesta los datos MS conocidos que correspondan al recurso. |
| Receptor de un recurso | MS no impone por sí solo mostrar, almacenar ni generar todo elemento. Se aplican las obligaciones de la transacción. |
| Repositorio que entrega un documento | Entregar la representación conservada conforme al contrato. |

La aplicación de estas reglas a los datos de pacientes y profesionales se explica en [HCENPatient](StructureDefinition-hcen-patient.md) y [HCENPractitioner](StructureDefinition-hcen-practitioner.md).

### Plan de verificación

| | |
| :--- | :--- |
| Datos | Validación contra perfiles; ejemplos positivos y negativos; códigos y dominios autorizados. |
| Pacientes | Registro inicial, actualización, coincidencias múltiples y correspondencia del MRN del cuerpo con el filtro. |
| Publicación | Metadatos válidos, referencias resueltas, envíos con y sin Binary, concordancia y rechazo de duplicados. |
| Consulta | Coincidencias, vacío, filtros acordados y paginación cuando se defina. |
| Recuperación | FHIR y CDA, como solicitante y proveedor, con errores y formatos admitidos. |
| Despliegue | Cobertura conjunta de productos y trazabilidad de sus versiones. |

La validación estructural no demuestra el comportamiento completo. Los [ejemplos del Core](ejemplos.md) y los [ejemplos HCEN](hcen-ejemplos.md) permiten revisar recursos y escenarios de CNU y publicación. Que los ejemplos compilen no demuestra que una implementación cumpla el intercambio completo. La validación de una implementación requiere evidencia de los intercambios y sus capacidades efectivamente disponibles.

### Seguridad y acreditación pendientes

Deben definirse o referenciarse autenticación, autorización, consentimiento, transporte seguro, auditoría, trazabilidad y condiciones operativas. La falta de un contrato publicado aquí no implica ausencia de obligaciones en esas materias.

