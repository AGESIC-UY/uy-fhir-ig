# Consulta documental con una coincidencia - Guía de Implementación FHIR de Uruguay v0.1.0

## Ejemplo Bundle: Consulta documental con una coincidencia



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "hcen-consulta-ejemplo",
  "type" : "searchset",
  "total" : 1,
  "link" : [{
    "relation" : "self",
    "url" : "https://example.org/plataforma/DocumentReference?patient.identifier=urn%3Aoid%3A2.16.858.2.99999999.72768.1%7CMRN-EJEMPLO-001"
  }],
  "entry" : [{
    "fullUrl" : "https://example.org/plataforma/DocumentReference/hcen-referencia-ejemplo",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "hcen-referencia-ejemplo",
      "meta" : {
        "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-document-reference"]
      },
      "language" : "es",
      "text" : {
        "status" : "generated",
        "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><a name=\"DocumentReference_hcen-referencia-ejemplo\"> </a><p>Metadatos de un documento ficticio de Ana Pérez Gómez. Incluye referencias a FHIR y CDA, autoría de Lucía Silva y custodia de ANDA a efectos del ejemplo técnico.</p></div>"
      },
      "contained" : [{
        "resourceType" : "Patient",
        "id" : "hcen-paciente-ejemplo",
        "meta" : {
          "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-patient"]
        },
        "language" : "es",
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Ana Pérez Gómez. MRN-EJEMPLO-001. Registro activo; sexo administrativo femenino; nacimiento 20/05/1985.</p></div>"
        },
        "identifier" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "MR",
              "display" : "Medical record number"
            }]
          },
          "system" : "urn:oid:2.16.858.2.99999999.72768.1",
          "value" : "MRN-EJEMPLO-001"
        }],
        "active" : true,
        "name" : [{
          "family" : "Pérez Gómez",
          "_family" : {
            "extension" : [{
              "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-primer-apellido",
              "valueString" : "Pérez"
            },
            {
              "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-segundo-apellido",
              "valueString" : "Gómez"
            }]
          },
          "given" : ["Ana"]
        }],
        "gender" : "female",
        "birthDate" : "1985-05-20"
      },
      {
        "resourceType" : "Practitioner",
        "id" : "hcen-profesional-ejemplo",
        "meta" : {
          "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner"]
        },
        "language" : "es",
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Lucía Silva. Cédula de ejemplo 12345672.</p></div>"
        },
        "identifier" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "NI",
              "display" : "National unique individual identifier"
            }]
          },
          "system" : "urn:oid:2.16.858.2.10000675.68909",
          "value" : "12345672"
        }],
        "name" : [{
          "family" : "Silva",
          "given" : ["Lucía"]
        }]
      },
      {
        "resourceType" : "Organization",
        "id" : "hcen-organizacion-ejemplo",
        "meta" : {
          "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-organization"]
        },
        "language" : "es",
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>ANDA. OID institucional utilizado para validar el ejemplo: urn:oid:2.16.858.2.10014456.72768.1.</p></div>"
        },
        "identifier" : [{
          "type" : {
            "coding" : [{
              "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
              "code" : "XX",
              "display" : "Organization identifier"
            }]
          },
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:oid:2.16.858.2.10014456.72768.1"
        }],
        "name" : "ANDA"
      },
      {
        "resourceType" : "PractitionerRole",
        "id" : "hcen-rol-ejemplo",
        "meta" : {
          "profile" : ["http://fhir.hcen.gub.uy/StructureDefinition/hcen-practitioner-role"]
        },
        "language" : "es",
        "text" : {
          "status" : "generated",
          "div" : "<div xml:lang=\"es\" xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"es\"><p>Lucía Silva ejerce en ANDA a efectos del ejemplo técnico.</p></div>"
        },
        "practitioner" : {
          "reference" : "#hcen-profesional-ejemplo"
        },
        "organization" : {
          "reference" : "#hcen-organizacion-ejemplo"
        }
      }],
      "extension" : [{
        "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-repository-id",
        "valueIdentifier" : {
          "system" : "urn:ietf:rfc:3986",
          "value" : "urn:oid:2.16.858.2.99999999.1"
        }
      }],
      "masterIdentifier" : {
        "use" : "usual",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:oid:2.16.858.2.99999999.67430.20260917100000.1"
      },
      "identifier" : [{
        "use" : "official",
        "system" : "urn:ietf:rfc:3986",
        "value" : "urn:uuid:1.2.16.858.2.99999999.67430.20260917100000.1"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "6821000179104"
        }]
      },
      "category" : [{
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "34108-1"
        }]
      }],
      "subject" : {
        "reference" : "#hcen-paciente-ejemplo"
      },
      "date" : "2026-09-17T10:00:00-03:00",
      "author" : [{
        "reference" : "#hcen-rol-ejemplo"
      }],
      "custodian" : {
        "reference" : "#hcen-organizacion-ejemplo"
      },
      "securityLabel" : [{
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-Confidentiality",
          "code" : "N"
        }]
      }],
      "content" : [{
        "attachment" : {
          "extension" : [{
            "url" : "http://fhir.hcen.gub.uy/StructureDefinition/ext-binary-resource-id",
            "valueReference" : {
              "reference" : "https://example.org/plataforma/documentos/ejemplo/cda"
            }
          }],
          "contentType" : "application/fhir+json",
          "language" : "es-UY",
          "url" : "https://example.org/plataforma/documentos/ejemplo/fhir",
          "title" : "Documento de prueba de interoperabilidad",
          "creation" : "2026-09-17T10:00:00-03:00"
        },
        "format" : {
          "system" : "http://ihe.net/fhir/ihe.formatcode.fhir/CodeSystem/formatcode",
          "code" : "urn:ihe:iti:xds:2017:mimeTypeSufficient"
        }
      }],
      "context" : {
        "facilityType" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "22232009"
          }]
        },
        "practiceSetting" : {
          "coding" : [{
            "system" : "http://snomed.info/sct",
            "code" : "700232004"
          }]
        },
        "sourcePatientInfo" : {
          "reference" : "#hcen-paciente-ejemplo"
        }
      }
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
